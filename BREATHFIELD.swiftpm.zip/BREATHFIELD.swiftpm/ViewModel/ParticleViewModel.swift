//
//  ParticleViewModel.swift
//  POC — Captura de gestos
//
//  Created by Miqueias Saldanha on 12/01/26.
//

import CoreGraphics
import Foundation

final class ParticleViewModel {

    private(set) var particles: [Particle] = []

    private let particleCount = 120
    private let movementRange: ClosedRange<CGFloat> = -0.15...0.15
    private var bounds: CGSize = .zero

    private var gestureEnergy: CGFloat = 0
    private var gestureSmoothness: CGFloat = 0

    func configure(bounds: CGSize) {
        self.bounds = bounds
        createParticles()
    }

    private func createParticles() {
        particles = (0..<particleCount).map { _ in
            let color = CGColor(red: 0.6, green: 0.7, blue: 0.75, alpha: 0.6)
            return Particle(
                position: CGPoint(
                    x: CGFloat.random(in: 0...bounds.width),
                    y: CGFloat.random(in: 0...bounds.height)
                ),
                velocity: CGVector(
                    dx: CGFloat.random(in: movementRange),
                    dy: CGFloat.random(in: movementRange)
                ),
                radius: CGFloat.random(in: 2...4),
                baseColor: color,
                currentColor: color
            )
        }
    }

    func update() {
        for i in particles.indices {
            particles[i].position.x += particles[i].velocity.dx
            particles[i].position.y += particles[i].velocity.dy

            wrap(&particles[i])

            particles[i].velocity.dx *= 0.98
            particles[i].velocity.dy *= 0.98

            particles[i].currentColor = interpolate(
                from: particles[i].currentColor,
                to: particles[i].baseColor,
                factor: 0.05
            )
        }
    }

    func applyGesture(speed: CGFloat, smoothness: CGFloat) {
        gestureEnergy = min(speed / 800, 1)
        gestureSmoothness = smoothness

        for i in particles.indices {
            let chaos = 1 - gestureSmoothness

            let jitterX = CGFloat.random(in: -0.3...0.3) * chaos
            let jitterY = CGFloat.random(in: -0.3...0.3) * chaos

            particles[i].velocity.dx += jitterX * gestureEnergy
            particles[i].velocity.dy += jitterY * gestureEnergy

            let saturationBoost = gestureSmoothness * gestureEnergy
            particles[i].currentColor = CGColor(
                red: 0.6 + saturationBoost * 0.3,
                green: 0.7 + saturationBoost * 0.2,
                blue: 0.75 + saturationBoost * 0.1,
                alpha: 0.6
            )
        }
    }

    /// Para o toque(rotas)
    private func wrap(_ particle: inout Particle) {
        if particle.position.x < 0 { particle.position.x = bounds.width }
        if particle.position.x > bounds.width { particle.position.x = 0 }
        if particle.position.y < 0 { particle.position.y = bounds.height }
        if particle.position.y > bounds.height { particle.position.y = 0 }
    }

    private func interpolate(from: CGColor, to: CGColor, factor: CGFloat) -> CGColor {
        let f = max(0, min(factor, 1))
        let fc = from.components ?? [0,0,0,0]
        let tc = to.components ?? [0,0,0,0]

        return CGColor(
            red: fc[0] + (tc[0] - fc[0]) * f,
            green: fc[1] + (tc[1] - fc[1]) * f,
            blue: fc[2] + (tc[2] - fc[2]) * f,
            alpha: fc[3] + (tc[3] - fc[3]) * f
        )
    }
}
