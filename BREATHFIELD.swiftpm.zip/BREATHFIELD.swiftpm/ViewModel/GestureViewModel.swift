//
//  GestureViewModel.swift
//  POC — Captura de gestos
//
//  Created by Miqueias Saldanha on 12/01/26.
//

import Foundation
import CoreGraphics

final class GestureViewModel {

    private(set) var points: [StrokePoint] = []

    var currentSpeed: CGFloat = 0
    var smoothness: CGFloat = 0
    var averagePressure: CGFloat = 0

    func beginStroke(at point: CGPoint, time: TimeInterval, pressure: CGFloat, isPencil: Bool) {
        points = [StrokePoint(
            position: point,
            timestamp: time,
            pressure: pressure,
            isPencil: isPencil
        )]
    }

    func addPoint(_ point: CGPoint, time: TimeInterval, pressure: CGFloat, isPencil: Bool) {
        guard let last = points.last else { return }

        let dx = point.x - last.position.x
        let dy = point.y - last.position.y
        let distance = sqrt(dx*dx + dy*dy)
        let dt = CGFloat(time - last.timestamp)

        if dt > 0 {
            currentSpeed = distance / dt
        }

        points.append(StrokePoint(
            position: point,
            timestamp: time,
            pressure: pressure,
            isPencil: isPencil
        ))

        analyzeSmoothness()
        analyzePressure()
    }

    func endStroke() {
        points.removeAll()
        currentSpeed = 0
        smoothness = 0
        averagePressure = 0
    }

    private func analyzeSmoothness() {
        guard points.count > 4 else { return }

        var angleChange: CGFloat = 0

        for i in 2..<points.count {
            let a = points[i-2].position
            let b = points[i-1].position
            let c = points[i].position

            let v1 = CGVector(dx: b.x - a.x, dy: b.y - a.y)
            let v2 = CGVector(dx: c.x - b.x, dy: c.y - b.y)

            let dot = v1.dx * v2.dx + v1.dy * v2.dy
            let mag = hypot(v1.dx, v1.dy) * hypot(v2.dx, v2.dy)

            if mag > 0 {
                let cos = dot / mag
                angleChange += abs(acos(min(max(cos, -1), 1)))
            }
        }

        let pencilBonus = points.last?.isPencil == true ? 0.2 : 0
        smoothness = min(1, max(0, 1 - angleChange / 10 + pencilBonus))
    }

    private func analyzePressure() {
        guard !points.isEmpty else { return }
        let total = points.reduce(CGFloat(0)) { $0 + $1.pressure }
        averagePressure = total / CGFloat(points.count)
    }
}
