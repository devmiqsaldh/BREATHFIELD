import SwiftUI
import SpriteKit

struct ContentView: View {

    private let viewModel = ParticleViewModel()

    var body: some View {
        SpriteView(scene: makeScene())
            .ignoresSafeArea()
    }

    private func makeScene() -> SKScene {
        let scene = ParticleScene(viewModel: viewModel)
        scene.scaleMode = .resizeFill
        return scene
    }
}


