//
//  Particle.swift
//  POC — Captura de gestos
//
//  Created by Miqueias Saldanha on 12/01/26.
//

import Foundation
import CoreGraphics

struct Particle {
    let id: UUID = UUID()
    var position: CGPoint
    var velocity: CGVector
    var radius: CGFloat
    var baseColor: CGColor = CGColor(red: 0.6, green: 0.7, blue: 0.75, alpha: 0.6)
    var currentColor: CGColor = CGColor(red: 0.6, green: 0.7, blue: 0.75, alpha: 0.6)
}

