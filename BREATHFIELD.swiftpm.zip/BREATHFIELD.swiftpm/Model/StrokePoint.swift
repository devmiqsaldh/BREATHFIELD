//
//  StrokePoint.swift
//  POC — Captura de gestos
//
//  Created by Miqueias Saldanha on 12/01/26.
//

import Foundation
import CoreGraphics

struct StrokePoint {
    let position: CGPoint
    let timestamp: TimeInterval
    let pressure: CGFloat     // para o toque
    let isPencil: Bool
}
