//
//  ParticleScene.swift
//  POC — Captura de gestos
//
//  Created by Miqueias Saldanha on 12/01/26.
//

import SpriteKit

final class ParticleScene: SKScene {
    
    private let viewModel: ParticleViewModel
    private var nodes: [UUID: SKShapeNode] = [:]
    
    private let gestureVM = GestureViewModel()
    
    init(viewModel: ParticleViewModel) {
        self.viewModel = viewModel
        super.init(size: .zero)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.96, green: 0.97, blue: 0.98, alpha: 1)
        viewModel.configure(bounds: size)
        createNodes()
    }
    
    private func createNodes() {
        for particle in viewModel.particles {
            let node = SKShapeNode(circleOfRadius: particle.radius)
            node.fillColor = SKColor(cgColor: particle.currentColor)
            node.strokeColor = .clear
            node.glowWidth = 1.5
            node.position = particle.position
            
            addChild(node)
            nodes[particle.id] = node
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        viewModel.update()
        viewModel.applyGesture(
            speed: gestureVM.currentSpeed,
            smoothness: gestureVM.smoothness
        )
        syncNodes()
    }
    
    private func syncNodes() {
        for particle in viewModel.particles {
            if let node = nodes[particle.id] {
                node.position = particle.position
                node.fillColor = SKColor(cgColor: particle.currentColor)
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        
        let location = t.location(in: self)
        let isPencil = t.type == .pencil
        let pressure = isPencil ? t.force / t.maximumPossibleForce : 1.0
        
        gestureVM.beginStroke(
            at: location,
            time: t.timestamp,
            pressure: pressure,
            isPencil: isPencil
        )
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let t = touches.first else { return }
        
        let location = t.location(in: self)
        let isPencil = t.type == .pencil
        let pressure = isPencil ? t.force / t.maximumPossibleForce : 1.0
        
        gestureVM.addPoint(
            location,
            time: t.timestamp,
            pressure: pressure,
            isPencil: isPencil
        )
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        gestureVM.endStroke()
    }
    
}
